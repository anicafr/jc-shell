/*
// jc-shell - exercicio 1, version 1
// Sistemas Operativos, DEI-CC/FC/UAN 2020
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>
#include "list.h"
#include "commandlinereader.h"



lista* inicialiZarListaPid(){
    lista *list=(lista*)malloc(sizeof (lista));
    list->cabeca=NULL;
    return list;
}
void listarProcesso(lista* list){
    printf("listar os processos com o tempo de inicio e fim.\n");
    No* aux=list->cabeca; int i=1;
    while((aux!=NULL)){
        printf("%d\tPID: %d\tTEMPO DE INICIO: %s",i, aux->pid, ctime(&(aux->tempoInicio)));
	    printf("\tSTATUS: %d\tTEMPO DO FINAL: %s\n",(aux->estado), ctime(&(aux->tempoFinal)));
        aux=aux->proximo;i++;
    }
    printf("Fim Da Lista.\n");
}
void atualizacaoTempoProcesso(lista *list, int pid, time_t tempoFinal, int estado){
   No *aux=list->cabeca;
   while(aux!=NULL){
       if(aux->pid==pid){
            aux->tempoFinal=tempoFinal;
            aux->estado=estado;
            break;
            }
        aux=aux->proximo;
    }
    printf("teminated process with pid: %d\n", pid);
}      
void EliminarLista(lista *list){
    No *elemento=list->cabeca, *proximoElemento;
    while(elemento!=NULL){
        proximoElemento=elemento->proximo;
        free(elemento);
        elemento=proximoElemento;
    } free(list);
}
int inserirNaLista(lista *list, int pid, time_t tempoInicio){
    if(list==NULL) return 0;
    No *novo=(No*)malloc(sizeof(No));
    if(novo==NULL) return 0;
    novo->pid= pid;
    novo->tempoInicio=tempoInicio;
    novo->tempoFinal=0;
    novo->estado=0;
    novo->proximo=NULL;
   if((list->cabeca)==NULL){
       list->cabeca=novo;
       return 1;
   }else{
       No *aux= list->cabeca;
       while(aux->proximo!=NULL)
           aux=aux->proximo;
       aux->proximo=novo;
   }
   return 1;
}
void *tarefaMonitora(){
    printf("*************  TAREFA MONITORA  ****************.\n");
    while(1) {
        sem_wait(&semaforoMonitor);
        pthread_mutex_lock(&buffer_mutex);
        if(numeroFilhos == 0 && controlarExite == 1) {
            pthread_mutex_unlock(&buffer_mutex);
            printf("********TAREFA MONITORA TERMINOU ********\n");
            break;
        }
        pthread_mutex_unlock(&buffer_mutex);
        childpid = wait(&status);
        if (childpid == -1) {
            perror("Error waiting for child");
            exit(EXIT_FAILURE);
        }
        pthread_mutex_lock(&buffer_mutex);
        numeroFilhos --;
        atualizacaoTempoProcesso(listPid, childpid, time(NULL), WIFEXITED(status));
        pthread_mutex_unlock(&buffer_mutex);
        sem_post(&semaforo);
    }
    pthread_exit(NULL);
}
int main (int argc, char **argv){
    char buffer[BUFFER_SIZE], *args[MAXARGS];
    listPid=inicialiZarListaPid();
    if(argc!=2) argc=2;
    sem_init(&semaforo, 0, argc);
    sem_init(&semaforoMonitor, 0, 0);
    pthread_mutex_init(&buffer_mutex, NULL);
    pthread_create(&thread, NULL, tarefaMonitora, NULL);
    while(1){
        pthread_mutex_lock(&buffer_mutex);
        numeroArgumentos = readLineArguments(args, MAXARGS, buffer, BUFFER_SIZE);
        pthread_mutex_unlock(&buffer_mutex);
        if (strcmp(args[0], "exit") == 0) {
            sem_post(&semaforoMonitor);
            break;
        }
        if (numeroArgumentos == 0) continue;
        if (numeroArgumentos < 0) {
            printf("Erro no readLineArguments()\n");
            continue;
        }
        sem_wait(&semaforo);
        int pid = fork();
        if(pid <0) {
            perror("Failed to create new process.");
            exit(EXIT_FAILURE);
        } else
            if (pid > 0) {  
                pthread_mutex_lock(&buffer_mutex);
                numeroFilhos ++;
                inserirNaLista(listPid, pid, time(NULL));
                pthread_mutex_unlock(&buffer_mutex);
                sem_post(&semaforoMonitor);
            }else 
                if (pid == 0) { 
                    if (execv(args[0], args) == -1) {
                        perror("Could not run child program. Child will exit.");
                        exit(EXIT_FAILURE);
                    }
                }
    }
    pthread_mutex_lock(&buffer_mutex);
    controlarExite = 1;
    pthread_mutex_unlock(&buffer_mutex);
    pthread_join(thread, NULL);
    listarProcesso(listPid);
    /*pthread_mutex_destroy(&buffer_mutex);
    sem_destroy(&semaforo);
    sem_destroy(&semaforoMonitor);
    EliminarLista(listPid);*/
    return 0;
}