#ifndef LIST_H
#define LIST_H

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#define MAXARGS 7
#define BUFFER_SIZE 100

typedef struct no{
    int pid,estado;
    time_t tempoInicio,tempoFinal;
    struct no *proximo;
}No;

typedef struct{
    No *cabeca;
}lista;

int numeroArgumentos,status,childpid, controlarExite=0;
pthread_mutex_t buffer_mutex;
pthread_t thread;
lista *listPid;
int numeroFilhos = 0;
int maximaConcorrencia=2;
sem_t semaforo;
sem_t semaforoMonitor;

lista* inicialiZarListaPid();
int inserirNaLista(lista *list, int pid, time_t tempoInicio);
void* tarefaMonitora();
void atualizacaoTempoProcesso(lista *list, int pid, time_t endtime,int estado);
void listarProcesso(lista *list);

#endif 
